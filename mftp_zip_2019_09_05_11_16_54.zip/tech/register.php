 <?php

 $servername = "sql306.epizy.com";
$username = "epiz_23882640";
$password = "XSkvF0AtCp";

try {
    $conn = new PDO("mysql:host=$servername;dbname=epiz_23882640_techaware", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   // echo "Connected successfully"; 
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
    
    if(isset($_POST['submit'])) {
        $errMsg = '';
        // Get data from FROM
        $name = $_POST['name'];
        $email = $_POST['email'];
        $reason = $_POST['reason'];
        $age = $_POST['age'];

        if($errMsg == ''){
            try {
                $stmt = $conn->prepare('INSERT INTO users (name, email, reason, age) VALUES (:name, :email, :reason,  :age)');
                $stmt->execute(array(
                    ':name' => $name,
                    ':email' => $email,
                    ':reason' => $reason,
                    ':age' => $age,

                    ));
        //  header('location:ticket.php?successfull');
                //exit;
            }
            catch(PDOException $e) {
                echo $e->getMessage();
            }
        }
    }

?>

<!doctype html>
<html lang="zxx">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Event Registration
     | Tech Aware</title>
    <link rel="icon" href="img/favicon.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- animate CSS -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- owl carousel CSS -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <!-- font awesome CSS -->
    <link rel="stylesheet" href="css/all.css">
    <!-- flaticon CSS -->
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <!-- font awesome CSS -->
    <link rel="stylesheet" href="css/magnific-popup.css">
    <!-- swiper CSS -->
    <link rel="stylesheet" href="css/slick.css">
    <!-- style CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!--::header part start::-->
    <header class="main_menu single_page_menu">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="navbar-brand" href="index.html"  style="color: white;"><h3 style="color: white;">Tech Aware</h3>
                        </a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="menu_icon"></span>
                        </button>

                        <div class="collapse navbar-collapse main-menu-item" id="navbarSupportedContent">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.html">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="event.html">event</a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="single-blog.html" id="navbarDropdown"
                                        role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Blog
                                    </a>
                                </li>
                                                               <li class="nav-item">
                                    <a class="nav-link" href="contact.php">Contact</a>
                                </li>
                            </ul>
                        </div>
                      <!--  <a href="register.php" class="d-none d-sm-block btn_1">SIGN UP FOR AN EVENT</a>-->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!--::Header part end::-->

    <!-- breadcrumb start-->
    <section class="breadcrumb breadcrumb_bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb_iner text-center">
                        <div class="breadcrumb_iner_item">
                            <h2>registration</h2>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb start-->

  <!-- ================ contact section start ================= -->
  <section class="contact-section section_padding">
    <div class="container">



      <div class="row">
        <div class="col-12">
          <h2 class="contact-title">Event Registration</h2>
        </div>
        <div class="col-lg-8">
          <form class="form-contact contact_form" action="register.php" method="post" id="contactForm">
            <div class="row">
              <div class="col-12">
                <div class="form-group">
                        <input class="form-control" name="name" id="name" type="text"
                placeholder='Enter your name' required>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                  <input class="form-control" name="age" id="name" type="number"
                placeholder='Age..' required pattern="[0-9]+">
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                  <input class="form-control" name="email" id="email" type="email" placeholder='Enter email address' required>
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                 <textarea class="form-control w-100" name="reason" id="message" cols="30" rows="9"
                    placeholder='Reason for joing softnotch' required></textarea>
                </div>
              </div>
            </div>
            <div class="form-group mt-3">
              <button type="submit" class="button button-contactForm btn_1" name="submit">Register <i class="flaticon-right-arrow"></i> </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
  <!-- ================ contact section end ================= -->

  <!--::footer_part start::-->
 <footer class="footer_part">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 col-md-4 col-lg-4">
                    <div class="single_footer_part">
                        <a href="index.html" class="footer_logo_iner"><h3>Tech Aware</h3> </a>
                        <p>Tech Aware is a platform that promotes and inspires exceptional minds in the tech industry. It is an arm of Softnotch that organizes events for both the promotion and inspiring of young minds within our own silicon value. It is made up of different youths who are passionate about making Nigeria one of the best tech country in Africa.
                        </p>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4 col-lg-2">
                    <div class="single_footer_part">
                        <h4>About Us</h4>
                        <ul class="list-unstyled">
                            <li><a href="">General Computer Knowledge</a></li>
                            <li><a href="">Advanced Kids in coding</a></li>
                            <li><a href="">Website and Web App Development</a></li>
                            <li><a href="">Marketing Service</a></li>
                            <li><a href="">Software development</a></li>
                        </ul>
                    </div>
                </div>
             
                <div class="col-sm-4 col-md-4 col-lg-2">
                    <div class="single_footer_part">
                        <h4>Contact Info</h4>
                        <ul class="list-unstyled">
                            <li><a href="">Address: 2 Ajayi Aina Street opposite Depper life church</a></li>
                            <li><a href="">Phone: +234 806 308 1972</a></li>
                            <li><a href="">Email: techaware2019@gmail.com</a></li>
                        </ul>
                    </div>
                </div>

            </div>
            <hr>
            <div class="row">
                <div class="col-lg-8">
                    <div class="copyright_text">
                        <P><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="ti-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></P>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="footer_icon social_icon">
                        <ul class="list-unstyled">
                            <li><a href="#" class="single_social_icon"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#" class="single_social_icon"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#" class="single_social_icon"><i class="fas fa-globe"></i></a></li>
                            <li><a href="#" class="single_social_icon"><i class="fab fa-behance"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
  <!--::footer_part end::-->

  <!-- jquery plugins here-->
  <script src="js/jquery-1.12.1.min.js"></script>
  <!-- popper js -->
  <script src="js/popper.min.js"></script>
  <!-- bootstrap js -->
  <script src="js/bootstrap.min.js"></script>
  <!-- easing js -->
  <script src="js/jquery.magnific-popup.js"></script>
  <!-- swiper js -->
  <script src="js/swiper.min.js"></script>
  <!-- swiper js -->
  <script src="js/masonry.pkgd.js"></script>
  <!-- particles js -->
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.nice-select.min.js"></script>
  <!-- slick js -->
  <script src="js/slick.min.js"></script>
  <script src="js/jquery.counterup.min.js"></script>
  <script src="js/waypoints.min.js"></script>

  <!-- custom js -->
  <script src="js/custom.js"></script>
      <script src="https://smtpjs.com/v3/smtp.js"></script>
<script type="text/javascript">
Email.send({
    Host : "smtp.gmail.com",
    Username : "techaware2019@gmail.com",
    Password : "qQqwerty1@",
    To : '<?php echo $_POST['email']; ?>',
    From : "techaware2019@gmail.com",
    Subject : "Soft Notch Registeration",
    Body : "Your registration code is <?php echo $age * 5;?> <?php echo $_POST['name']; ?> _techaware19"
}).then(
console.log('Good to go')
);
</script>
</body>

</html>